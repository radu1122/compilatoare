import java.io.IOException;
import java.util.*;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTreeWalker;


public class Test {

    public static void main(String[] args) throws IOException {
        var input = CharStreams.fromFileName("program.txt");

        var lexer = new CPLangLexer(input);
        var tokenStream = new CommonTokenStream(lexer);

        /*
        tokenStream.fill();
        List<Token> tokens = tokenStream.getTokens();
        for (var token : tokens) {
            var text = token.getText();
            var type = CPLangLexer.VOCABULARY.getSymbolicName(token.getType());

            System.out.println(text + " : " + type);
        }
        */

        var parser = new CPLangParser(tokenStream);
        var tree = parser.expr();
        System.out.println(tree.toStringTree(parser));

        // Visitor-ul de mai jos parcurge arborele de derivare și construiește
        // un arbore de sintaxă abstractă (AST).
        var astConstructionVisitor = new CPLangParserBaseVisitor<ASTNode>() {
            @Override
            public ASTNode visitId(CPLangParser.IdContext ctx) {
                return new Id(ctx.ID().getSymbol());
            }

            @Override
            public ASTNode visitInt(CPLangParser.IntContext ctx) {
                return new Int(ctx.INT().getSymbol());
            }

            @Override
            public ASTNode visitIf(CPLangParser.IfContext ctx) {
                return new If((Expression)visit(ctx.cond),
                        (Expression)visit(ctx.thenBranch),
                        (Expression)visit(ctx.elseBranch),
                        ctx.start);
            }

        };

        var ast = astConstructionVisitor.visit(tree);

        var printVisitor = new ASTVisitor<Void>() {
            int indent = 0;

            @Override
            public Void visit(Id id) {
                printIndent("ID " + id.token.getText());
                return null;
            }

            @Override
            public Void visit(Int intt) {
                printIndent("INT " + intt.token.getText());
                return null;
            }

            @Override
            public Void visit(If iff) {
                printIndent("IF");
                indent++;
                iff.cond.accept(this);
                iff.thenBranch.accept(this);
                iff.elseBranch.accept(this);
                indent--;
                return null;
            }

            @Override
            public Void visit(Call call) {
                return null;
            }

            @Override
            public Void visit(UnaryMinus unaryMinus) {
                return null;
            }

            @Override
            public Void visit(Mult mult) {
                return null;
            }

            @Override
            public Void visit(Div div) {
                return null;
            }

            @Override
            public Void visit(Plus plus) {
                return null;
            }

            @Override
            public Void visit(Minus minus) {
                return null;
            }

            @Override
            public Void visit(Relational relational) {
                return null;
            }

            @Override
            public Void visit(Assign assign) {
                return null;
            }

            @Override
            public Void visit(FloatNode floatt) {
                return null;
            }

            @Override
            public Void visit(Bool booll) {
                return null;
            }

            @Override
            public Void visit(Formal formal) {
                return null;
            }

            @Override
            public Void visit(VarDef varDef) {
                return null;
            }

            @Override
            public Void visit(FuncDef funcDef) {
                return null;
            }

            @Override
            public Void visit(Program program) {
                return null;
            }


            void printIndent(String str) {
                for (int i = 0; i < indent; i++)
                    System.out.print("\t");
                System.out.println(str);
            }
        };


        System.out.println("The AST is");
        ast.accept(printVisitor);
    }


}
